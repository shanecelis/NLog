# 0.3.3

##### NLog.Unity
- Added DontDestroyOnLoad to NLogConfig

##### Other
- buildPackage.sh includes RELEASE_NOTES.md to NLog.zip
