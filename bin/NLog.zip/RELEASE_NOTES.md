# 0.3.4

##### NLog.Unity
- Upgraded Unity project to Unity 5.0


# 0.3.3

##### NLog.Unity
- Added DontDestroyOnLoad to NLogConfig

##### Other
- buildPackage.sh includes RELEASE_NOTES.md to NLog.zip
