namespace NLog {
    public enum LogLevel : byte {
        On,
        Trace,
        Debug,
        Info,
        Warn,
        Error,
        Fatal,
        Off
    }
}
